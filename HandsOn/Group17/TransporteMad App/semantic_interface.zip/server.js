const express = require('express');
const morgan = require("morgan");
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { request } = require('http');

const app = express();

// Configuration
const PORT = 8081;
const API_SERVICE_URL = "http://localhost:9999";

//app.use(morgan('dev'));

app.use('/', cors(), (req, res, next) => {
    let path = encodeURI(`http://localhost:9999${req.path}`);
    let _req = request(path, {method: 'POST'});
    let content = `query=${req.query.query}`;
    _req.setHeader('Content-Type', 'application/x-www-form-urlencoded');
    _req.setHeader('Content-Length', content.length);
    _req.setHeader('Accept', 'application/sparql-results+json');
    _req.setHeader('Accept-Encoding', 'gzip, deflate, br');
    _req.end(content);
    _req.on('response', (_res) => {
        res.writeHead(_res.statusCode, _res.statusMessage);
        if (_res.statusCode > 299 || _res.statusCode < 200) return res.end();
        let data = '';
        _res.on('data', (chk) => { data += chk.toString(); });
        _res.on('end', (chk) => {
            if (chk) data += chk.toString();
            res.end(data);
        })
    })
});

app.listen(PORT);