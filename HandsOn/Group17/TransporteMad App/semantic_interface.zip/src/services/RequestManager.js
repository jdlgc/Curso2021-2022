import axios from 'axios';

class RequestManager {

    static Queries = {
        local: {
            district: {
                "BiciMad": 'PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX dbr:<http://transporteMad.example.org/Ontology/> PREFIX dbo:<http://transporteMad.example.org/Ontology/> PREFIX dis:<http://transporteMad.example.org/Ontology/Distrito/> PREFIX pob:<http://transporteMad.example.org/Ontology/Poblacion/> PREFIX res:<http://transporteMad.example.org#> PREFIX owl:<http://www.w3.org/2002/07/owl#> SELECT ?id WHERE { dis:$Distrito$ owl:sameAs ?id } limit 1',
                "Taxi": `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX dbr: <http://transporteMad.example.org/Ontology/> PREFIX dbo: <http://transporteMad.example.org/Ontology/> PREFIX dis: <http://transporteMad.example.org/Ontology/Distrito/> PREFIX pob: <http://transporteMad.example.org/Ontology/Poblacion/> PREFIX res: <http://transporteMad.example.org#> PREFIX owl: <http://www.w3.org/2002/07/owl#> SELECT ?id WHERE { dis:$Distrito$ owl:sameAs ?id } limit 1`,
                "Cercanias": `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX dbr: <http://transporteMad.example.org/Ontology/> PREFIX dbo: <http://transporteMad.example.org/Ontology/> PREFIX dis: <http://transporteMad.example.org/Ontology/Distrito/> PREFIX pob: <http://transporteMad.example.org/Ontology/Poblacion/> PREFIX res: <http://transporteMad.example.org#> PREFIX owl: <http://www.w3.org/2002/07/owl#> SELECT ?id WHERE { pob:$Poblacion$ owl:sameAs ?id } limit 1`,
            },
            transport: {
                "BiciMad": `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX dbr: <http://transporteMad.example.org/Ontology/> PREFIX dbo: <http://transporteMad.example.org/Ontology/> PREFIX dis: <http://transporteMad.example.org/Ontology/Distrito/> PREFIX pob: <http://transporteMad.example.org/Ontology/Poblacion/> PREFIX res: <http://transporteMad.example.org#> PREFIX owl: <http://www.w3.org/2002/07/owl#> SELECT ?id ?Direccion WHERE {     ?id rdf:type dbr:EstacionBiciMad .     ?id dbr:direccion ?Direccion .     ?id dbr:distrito "$Distrito$" }`,
                "Taxi": `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        PREFIX dbr: <http://transporteMad.example.org/Ontology/>
                        PREFIX dbo: <http://transporteMad.example.org/Ontology/>
                        PREFIX dis: <http://transporteMad.example.org/Ontology/Distrito/>
                        PREFIX pob: <http://transporteMad.example.org/Ontology/Poblacion/>
                        PREFIX res: <http://transporteMad.example.org#>
                        PREFIX owl: <http://www.w3.org/2002/07/owl#>
                        
                        SELECT ?id ?Direccion WHERE {
                            ?id rdf:type dbr:ParadaTaxi .
                            ?id dbr:Direccion ?Direccion .
                            ?id dbr:Distrito "$Distrito$"
                        }`,
                "Cercanias": `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                            PREFIX dbr: <http://transporteMad.example.org/Ontology/>
                            PREFIX dbo: <http://transporteMad.example.org/Ontology/>
                            PREFIX dis: <http://transporteMad.example.org/Ontology/Distrito/>
                            PREFIX pob: <http://transporteMad.example.org/Ontology/Poblacion/>
                            PREFIX res: <http://transporteMad.example.org#>
                            PREFIX owl: <http://www.w3.org/2002/07/owl#>
                            
                            SELECT ?id ?Direccion WHERE {
                                ?id rdf:type dbr:EstacionCercanias .
                                  ?id dbr:Direccion ?Direccion .
                                  ?id dbr:Poblacion "$Poblacion$"
                            }`
            }
        },
        wiki: `SELECT ?pic WHERE { wd:$id$ wdt:P18 ?pic SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en" } }`
    }

    async getResultFromWikidata(query) {
        return axios.get(`https://query.wikidata.org/sparql?query=${encodeURIComponent(query)}`);
    }

    async getResultFromRDF(query) {
        return axios.get(encodeURI(`http://localhost:8081/blazegraph/sparql?query=${encodeURIComponent(query)}`), {
            headers: {
                'Accept': 'application/sparql-results+json',
                "Access-Control-Allow-Origin": "*"
            }
        });
    }


    async getSearchResult(type, district) {
        let idQueryData = await this.getResultFromRDF(RequestManager.Queries.local.district[type].replace(/\$Distrito\$|\$Poblacion\$/g, district));
        let districtQueryData = await this.getResultFromRDF(RequestManager.Queries.local.transport[type].replace(/\$Distrito\$|\$Poblacion\$/g, district));
        if(!idQueryData?.data?.results?.bindings[0]?.id?.value?.split('/')?.slice(-1)[0]) return {spots: districtQueryData.data.results.bindings};
        let code = idQueryData?.data?.results?.bindings[0]?.id?.value?.split('/')?.slice(-1)[0];
        let imageQueryData = await this.getResultFromWikidata(RequestManager.Queries.wiki.replace("$id$", code));
        return { spots: districtQueryData.data.results.bindings, image: imageQueryData.data.results.bindings[0].pic.value };
    }

}



export default new RequestManager();