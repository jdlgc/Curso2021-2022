import './App.css';
import { useState } from "react";
import requestManager from './services/RequestManager'

function App() {
  const [type, setType] = useState("");
  const [district, setDistrict] = useState("");
  const [image, setImage] = useState(null);
  const [results, setResults] = useState([]);
  return (
    <div className="App">
        <div className="buttons">
            <h1>RDF Search</h1>
            <div><input type="text" value={type} onChange={(ev) => setType(ev.target.value)} placeholder="Transport type"/></div>
            <div><input type="text" value={district} onChange={(ev) => setDistrict(ev.target.value)} placeholder="District"/></div>
            <div><button onClick={async () => {
                let response = await requestManager.getSearchResult(type, district);
                setImage(response.image);
                setResults(response.spots);
            }}>Search</button></div>
        </div>
        <div className="results">
            {
                image && <img src={image} alt="Area"/>
            }
            {
                results.map((res, i) => <div key={i}>
                <span>
                    { res.id.value.split("/").slice(-1)[0] }:
                </span>
                    <span>
                    { res.Direccion.value }
                </span>
                </div>)
            }
        </div>
    </div>
  );
}

export default App;
